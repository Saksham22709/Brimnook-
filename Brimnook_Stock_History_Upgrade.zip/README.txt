Brimnook Stock History Upgrade (free prototype)

New:
- Stock history screen in navigation
- Logs product creation, quick stock increases/decreases, stock edits, product detail edits, product deletion, and sample-data reset
- Export history to CSV
- Clear history without changing product quantities

Important:
- This remains a local browser demo. Data and history stay in localStorage on this browser/device.
- Stock decreases are recorded as "Stock reduced", not automatically as sales. Billing/sales integration is not included.
- No login, cloud sync, shared database, or production security.
- Test the new file before replacing the published index.html. Keep your old copy as a backup.
